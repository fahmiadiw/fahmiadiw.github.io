# validate.py: data checks before the dashboard

These are the eight validation rules (R1–R8) behind the one-pager *Before the Dashboard: Catching Silent Errors in Field & Routine Health Data*. The script checks a village population export and a health facility list before any analysis or dashboard uses them. It writes clean tables and an audit report, and exits with code 1 if a problem still blocks analysis.

## Run

```bash
pip install pandas shapely
python validate.py --pop raw_prima_431.tsv --fac faskes_v0_raw.tsv \
  --villages desa_boundaries.geojson --aliases aliases.csv --out clean
```

With the raw facility list, R6 fails and the exit code is 1, because 4 coordinates fall outside the regency and have to be collected again. Run it with `--fac faskes_corrected.tsv` to see every check pass (exit code 0).

## Rules

| Rule | Check | Result on the raw files |
|---|---|---|
| R1 | Keep village-level codes only; move subtotal rows to a side table | 18 subtotal rows removed (5 share a village name) |
| R2 | One row per village per period | 131 villages appear twice; row order mixes the periods in 66 |
| R3 | Village figures must reconcile to the official sub-district totals (tolerance 0.1%) | Newer period matches within 80 people (0.02%) |
| R4 | Normalise names, apply the reviewed alias table, then match to the boundary file | 24 exact-match failures, 0 left unmatched |
| R5 | Join on sub-district + name, never on name alone | Sidodadi exists in two sub-districts; 21 codes for 131 villages |
| R6 | Each facility point must fall inside its stated sub-district | 4 of 22 points outside the regency |
| R7 | Remove placeholder or template rows | 1 removed ("Klinik Utama Contoh") |
| R8 | Numeric fields must be numbers; "~" estimates become a value plus a flag | 24 cells flagged |

Name aliases are kept in `aliases.csv`, which a person reviews, rather than being fuzzy-matched automatically. That way every match can be traced and a wrong one can't slip through.

## Files

- `validate.py`: the rules
- `raw_prima_431.tsv`: Disdukcapil village population, as exported from the PRIMA portal (two unlabeled periods)
- `faskes_v0_raw.tsv` / `faskes_corrected.tsv`: facility list as first received, and after the coordinates were collected again
- `desa_boundaries.geojson`: BPS 2020 village boundaries (via HDX)
- `aliases.csv`: reviewed name aliases

Outputs: `population_clean.csv`, `facilities_clean.csv`, `audit_report.csv`

---
Fahmi Adi Wicaksono · Health & Spatial Data Analyst · [fahmiadiw.github.io](https://fahmiadiw.github.io)
