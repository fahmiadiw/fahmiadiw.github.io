"""
validate.py - rule-based checks for village population + health facility data
Pringsewu Regency, Lampung (Fahmi Adi Wicaksono)

Runs eight validation rules (R1-R8) on two raw inputs before any analysis or
dashboard uses them, writes clean tables, and prints an audit report.

Usage:
    python validate.py --pop raw_prima_431.tsv --fac faskes_v0_raw.tsv \
        --villages desa_boundaries.geojson --aliases aliases.csv --out clean/

Inputs
    --pop       Disdukcapil village population export (columns: Kode, Nama, Jumlah)
    --fac       facility list (nama, jenis, kecamatan, lat, lon, ... numeric staff fields)
    --villages  BPS village polygons (GeoJSON; properties: kecamatan, desa, kode)
    --aliases   reviewed name aliases (columns: raw_name, bps_name)

Requires: pandas, shapely
"""
import argparse, json, re, sys
from pathlib import Path
import pandas as pd
from shapely.geometry import shape, Point
from shapely.ops import unary_union

KEC_CODE = {'01': 'Pringsewu', '02': 'Gading Rejo', '03': 'Ambarawa', '04': 'Pardasuka',
            '05': 'Pagelaran', '06': 'Banyumas', '07': 'Adi Luwih', '08': 'Sukoharjo',
            '09': 'Pagelaran Utara'}
PLACEHOLDER = re.compile(r'\b(?:contoh|example|test|dummy|sample|xxx)\b', re.I)
NUMERIC_FAC = ['tempat_tidur', 'dokter', 'bidan', 'perawat']
RECONCILE_TOL = 0.001          # village sum must match sub-district total within 0.1 %

norm = lambda s: re.sub(r'[^a-z0-9]', '', str(s).lower())
report = []


def log(rule, status, msg):
    report.append((rule, status, msg))
    print(f'[{rule}] {status:<5} {msg}')


# ---------------------------------------------------------------- population
def check_population(pop_path, villages, aliases):
    raw = pd.read_csv(pop_path, sep='\t', dtype={'Kode': str})
    raw['level'] = raw.Kode.str.count(r'\.')
    raw['kecamatan'] = raw.Kode.str[6:8].map(KEC_CODE)

    # R1 - hierarchy: keep village-level rows only; subtotal rows go to a side table
    sub = raw[raw.level < 3].copy()
    vil = raw[raw.level == 3].copy()
    clash = sorted(set(sub.Nama) & set(vil.Nama))
    log('R1', 'FIX', f'{len(sub)} sub-district subtotal rows removed from {len(raw)} '
        f'({len(clash)} share a village name: {", ".join(clash)})')

    # R2 - uniqueness: exactly one row per (kecamatan, village) per period
    counts = vil.groupby(['kecamatan', 'Nama']).size()
    n_dup = int((counts > 1).sum())
    log('R2', 'FLAG' if n_dup else 'OK', f'{len(vil)} village rows for {len(counts)} villages; '
        f'{n_dup} villages appear more than once (unlabeled periods?)')
    g = vil.groupby(['kecamatan', 'Nama']).Jumlah
    periods = pd.DataFrame({'low': g.min(), 'high': g.max(), 'first': g.first()}).reset_index()
    mixed = int((periods['first'] != periods['high']).sum())
    log('R2', 'FLAG', f'row order does not identify the period in {mixed} villages '
        f'- "keep first" would mix periods')
    same = periods[periods.low == periods.high]
    if len(same):
        log('R2', 'NOTE', 'identical figures in both periods (query data owner): '
            + ', '.join(same.Nama))

    # R3 - reconciliation: which set of village figures reproduces official subtotals?
    sub['set'] = sub.Nama.str.startswith('KECAMATAN').map({True: 'B', False: 'A'})
    tot = sub.pivot_table(index='kecamatan', columns='set', values='Jumlah')
    vs = periods.groupby('kecamatan')[['low', 'high']].sum()
    best = None
    for col in ['high', 'low']:
        for s in ['A', 'B']:
            gap = (vs[col] - tot[s]).abs().sum()
            if best is None or gap < best[2]:
                best = (col, s, gap)
    col, s, gap = best
    pct = gap / tot[s].sum()
    log('R3', 'OK' if pct <= RECONCILE_TOL else 'FAIL',
        f'village "{col}" figures match subtotal set {s} within {int(gap)} people ({pct:.2%})')
    periods['penduduk'] = periods[col]

    # R4 - key match: normalise names, apply reviewed aliases, match to boundary file
    alias = {norm(a): norm(b) for a, b in zip(aliases.raw_name, aliases.bps_name)}
    periods['key'] = periods.Nama.map(norm).replace(alias)
    villages['key'] = villages.desa.map(norm)
    exact = villages.desa.str.upper().isin(set(vil.Nama)) | (villages.desa == 'Hutan')
    log('R4', 'FIX', f'{int((~exact).sum())} boundary villages fail an exact name match; '
        f'{len(alias)} reviewed aliases applied')

    # R5 - composite key: match on (kecamatan, name), never on name alone
    dup_names = periods.Nama.value_counts()
    dup_names = dup_names[dup_names > 1].index.tolist()
    log('R5', 'FIX', f'names used in more than one sub-district: {", ".join(dup_names) or "none"}'
        f'; codes are not unique ({vil.Kode.nunique()} codes for {len(counts)} villages)')
    periods['kkey'] = periods.kecamatan.map(norm)
    villages['kkey'] = villages.kecamatan.map(norm)
    m = villages.merge(periods[['kkey', 'key', 'penduduk']], on=['kkey', 'key'], how='left')
    unmatched = m[m.penduduk.isna() & (m.desa != 'Hutan')]
    log('R4', 'OK' if unmatched.empty else 'FAIL',
        f'{len(unmatched)} boundary villages left without population'
        + (': ' + ', '.join(unmatched.desa) if len(unmatched) else ''))
    m['penduduk'] = m.penduduk.fillna(0).astype(int)
    return m[['kode', 'kecamatan', 'desa', 'penduduk']]


# ---------------------------------------------------------------- facilities
def check_facilities(fac_path, villages_geo):
    f = pd.read_csv(fac_path, sep='\t', dtype=str)

    # R6 - point-in-polygon against the stated sub-district
    kec_poly = {}
    for k, grp in villages_geo.groupby('kecamatan'):
        kec_poly[norm(k)] = unary_union(list(grp.geometry))
    county = unary_union(list(kec_poly.values()))
    bad = []
    for _, r in f.iterrows():
        p = Point(float(r.lon), float(r.lat))
        poly = kec_poly.get(norm(r.kecamatan))
        if poly is None or not poly.contains(p):
            where = 'outside the regency' if not county.contains(p) else 'in another sub-district'
            bad.append(f'{r.nama} ({where})')
    log('R6', 'FAIL' if bad else 'OK', f'{len(bad)} of {len(f)} points not inside their stated '
        f'sub-district' + (': ' + '; '.join(bad) if bad else ''))

    # R7 - placeholder / template rows
    ph = f[f.nama.str.contains(PLACEHOLDER)]
    log('R7', 'FIX' if len(ph) else 'OK', f'{len(ph)} placeholder rows removed'
        + (': ' + ', '.join(ph.nama) if len(ph) else ''))
    f = f.drop(ph.index)

    # R8 - numeric fields: split estimates ("~150") into value + flag
    n_est = 0
    for c in NUMERIC_FAC:
        if c not in f: continue
        s = f[c].fillna('').str.strip()
        est = s.str.startswith('~')
        n_est += int(est.sum())
        f[c] = pd.to_numeric(s.str.lstrip('~').replace({'-': None, '': None}), errors='coerce')
        f[c + '_is_estimate'] = est
    log('R8', 'FLAG' if n_est else 'OK', f'{n_est} numeric cells hold estimates; kept as numbers '
        f'with an *_is_estimate flag')
    return f, bad


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pop', required=True); ap.add_argument('--fac', required=True)
    ap.add_argument('--villages', required=True); ap.add_argument('--aliases', required=True)
    ap.add_argument('--out', default='clean')
    a = ap.parse_args()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)

    gj = json.load(open(a.villages))
    villages = pd.DataFrame([x['properties'] for x in gj['features']])
    villages['geometry'] = [shape(x['geometry']).buffer(0) for x in gj['features']]

    print('== Population ==')
    pop = check_population(a.pop, villages.drop(columns='geometry').copy(),
                           pd.read_csv(a.aliases))
    print('== Facilities ==')
    fac, bad = check_facilities(a.fac, villages)

    pop.to_csv(out / 'population_clean.csv', index=False)
    fac.to_csv(out / 'facilities_clean.csv', index=False)
    pd.DataFrame(report, columns=['rule', 'status', 'message']).to_csv(out / 'audit_report.csv', index=False)
    print(f'\nTotal population: {pop.penduduk.sum():,} in {len(pop)} villages')
    print(f'Wrote {out}/population_clean.csv, facilities_clean.csv, audit_report.csv')
    # non-zero exit if anything still blocks analysis (useful in a scheduled pipeline)
    sys.exit(1 if any(s == 'FAIL' for _, s, _ in report) else 0)


if __name__ == '__main__':
    main()
